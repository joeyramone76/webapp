See doc/manual.pdf.
